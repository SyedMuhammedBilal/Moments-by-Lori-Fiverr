---
title: Pikachu
description: Pikachu is an Electric-type Pokémon introduced in Generation I.
type: Electric
---