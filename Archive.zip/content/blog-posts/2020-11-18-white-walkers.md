---
layout: blog
title: White walkers
picture: /images/fd2e9291-abc3-4dda-9c17-5b5de0b82043.jpeg
---
Power is power